/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JSFBeans;

import EJBs.CinemaEJB;
import Entities.Movies;
import Entities.Theaters;
import java.io.Serializable;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;

/**
 *
 * @author avaen
 */
@Named(value = "theatersMoviesManager")
@SessionScoped
public class TheatersMoviesManager implements Serializable {

    @EJB
    private CinemaEJB cinemaEJB;
    private Movies movies;
    private Theaters theaters;
    private String enterZipcode;
    private String enterTheaterName;
    private String enterShowtime;
    private int enterTicketAmount;
    private double totalAmount;

    //------------ GETTERS & SETTERS ------------//
    public CinemaEJB getCinemaEJB() {
        return cinemaEJB;
    }

    public void setCinemaEJB(CinemaEJB cinemaEJB) {
        this.cinemaEJB = cinemaEJB;
    }

    public Movies getMovies() {
        return movies;
    }

    public void setMovies(Movies movies) {
        this.movies = movies;
    }

    public Theaters getTheaters() {
        return theaters;
    }

    public void setTheaters(Theaters theaters) {
        this.theaters = theaters;
    }

    public String getEnterZipcode() {
        return enterZipcode;
    }

    public void setEnterZipcode(String enterZipcode) {
        this.enterZipcode = enterZipcode;
    }

    public String getEnterTheaterName() {
        return enterTheaterName;
    }

    public void setEnterTheaterName(String enterTheaterName) {
        this.enterTheaterName = enterTheaterName;
    }

    public String getEnterShowtime() {
        return enterShowtime;
    }

    public void setEnterShowtime(String enterShowtime) {
        this.enterShowtime = enterShowtime;
    }

    public int getEnterTicketAmount() {
        return enterTicketAmount;
    }

    public void setEnterTicketAmount(int enterTicketAmount) {
        this.enterTicketAmount = enterTicketAmount;
    }

    public double getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(double totalAmount) {
        this.totalAmount = totalAmount;
    }

    //------------ END OF GETTERS & SETTERS ------------//
    // Creates a new instance of TheatersMoviesManager
    public TheatersMoviesManager() {
    }

    /**
     * This will direct the user to the 'Theater Look Up' page after finding all
     * the theaters from a specified ZIP code. It will take the enterZipcode
     * value which is passed from the front end into the EJB's method to find
     * the theaters.
     *
     * @return
     */
    public String showTheatersByZipcode() {
        try {
            System.out.println(enterZipcode); // for debugging: prints obtained value from front end.
            theaters = cinemaEJB.findTheatersByZipcode(enterZipcode);
            return "TheatersLookUp.xhtml";
        } catch (Exception e) {
            return "No theaters found in the provided ZIP code.";
        }
    }

    public String processTickets() {
        System.out.println(enterTicketAmount); // for debugging: pritns obtained value from front end.
        totalAmount = enterTicketAmount * 10;
        System.out.println(totalAmount); // for debugging: pritns obtained value from front end.
        return "Checkout.xhtml";
    }

    public String finishCheckout() {
        return "ThankYou.xhtml";
    }

    /**
     * This will allow the front end to access the theater's filtered values
     * (column names). Flash allows the parameter to be preserved through a
     * request. The zipcode is saved in “Flash” memory. Flash memory is
     * preserved across one request, so it is there on the next request. If the
     * zipcode is there, it will be saved in flash. If it is not there, it will
     * be retrieved from flash.
     *
     * @return
     */
    public List<Theaters> getTheatersByZipList() {
        Flash flash = FacesContext.getCurrentInstance().getExternalContext().getFlash();
        if (enterZipcode != null) {
            flash.put("zipcode", enterZipcode);
        } else {
            enterZipcode = (String) flash.get("zipcode");
        }
        return cinemaEJB.getTheatersByZipcodeList(enterZipcode);
    }

    public String showSelectedShowtimeMovie(Movies movies) {
        // This pulls the parameter value from the front end. This will pull the theater name on whatever row was selected.
        FacesContext fc = FacesContext.getCurrentInstance();
        Map<String, String> params = fc.getExternalContext().getRequestParameterMap();
        enterShowtime = params.get("showtime");

        Flash flash = FacesContext.getCurrentInstance().getExternalContext().getFlash();
        if (enterShowtime != null) {
            flash.put("showtime", enterShowtime);
        } else {
            enterShowtime = (String) flash.get("showtime");
        }
        System.out.println(enterShowtime);
        this.movies = movies;
        return "SelectedShowtime.xhtml";
    }

    /**
     * This will get the theaterId from the front end user selection and find
     * all the movies by the specified theater using the theater ID. The
     * theaterId is found using the FacesContext and .get method.
     *
     * @return
     */
    public String showMoviesByTheaters() {
        FacesContext fc = FacesContext.getCurrentInstance();
        Map<String, String> params = fc.getExternalContext().getRequestParameterMap();
        String theaterName = params.get("theaterName");
        System.out.println(theaterName); // for debugging: prints obtained value from front end.
        movies = cinemaEJB.findMoviesByTheater(theaterName);
        return "MoviesLookUp.xhtml";
    }

    /**
     * This will allow the front end to access the movie's filtered values by
     * the theater. Flash allows the parameter to be preserved through a
     * request. The theaterName is saved in “Flash” memory. Flash memory is
     * preserved across one request, so it is there on the next request. If the
     * theaterName is there, it will be saved in flash. If it is not there, it
     * will be retrieved from flash.
     *
     * @return
     */
    public List<Movies> getMoviesByTheatersList() {
        // This pulls the parameter value from the front end. This will pull the theater name on whatever row was selected.
        FacesContext fc = FacesContext.getCurrentInstance();
        Map<String, String> params = fc.getExternalContext().getRequestParameterMap();
        enterTheaterName = params.get("theaterName");

        Flash flash = FacesContext.getCurrentInstance().getExternalContext().getFlash();
        if (enterTheaterName != null) {
            flash.put("theatername", enterTheaterName);
        } else {
            enterTheaterName = (String) flash.get("theatername");
        }
        return cinemaEJB.findMoviesByTheatersList(enterTheaterName);
    }

    public String goBackToMoviesList() {
        FacesContext fc = FacesContext.getCurrentInstance();
        Map<String, String> params = fc.getExternalContext().getRequestParameterMap();
        String theaterName = params.get("theaterName");
        movies = cinemaEJB.findMoviesByTheater(theaterName);
        return "MoviesLookUp.xhtml";
    }

    public String goBackToMovieDetails() {
        return "SelectedShowtime.xhtml";
    }

    public String goBackToTheatersList() {
        FacesContext fc = FacesContext.getCurrentInstance();
        Map<String, String> params = fc.getExternalContext().getRequestParameterMap();
        String zipcode = params.get("zipcode");
        theaters = cinemaEJB.findTheatersByZipcode(zipcode);
        return "TheatersLookUp.xhtml";
    }

    /**
     * public String showTheater() { try { theater =
     * theaterEJB.getTheater(zipcode); return "Theater.xhtml"; } catch
     * (Exception e) { return "No theater found."; }
     *
     *
     * }
     */
}
