/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package JSFBeans;

import EJBs.CinemaEJB;
import Entities.Movieposters;
import Entities.Movies;
import Entities.Theaters;
import java.util.List;
import java.util.Map;
import javax.ejb.EJB;
import javax.inject.Named;
import javax.enterprise.context.RequestScoped;
import javax.faces.context.FacesContext;
import javax.faces.context.Flash;

/**
 *
 * @author avaen
 */
@Named(value = "mainPageManager")
@RequestScoped
public class MainPageManager {

    @EJB
    private CinemaEJB cinemaEJB;
    private Movies movies;
    private Theaters theaters;
    private Movieposters moviePosters;
    private String moviePosterName;

     //------------ GETTERS & SETTERS ------------//

    public CinemaEJB getCinemaEJB() {
        return cinemaEJB;
    }

    public void setCinemaEJB(CinemaEJB cinemaEJB) {
        this.cinemaEJB = cinemaEJB;
    }

    public Movies getMovies() {
        return movies;
    }

    public void setMovies(Movies movies) {
        this.movies = movies;
    }

    public Theaters getTheaters() {
        return theaters;
    }

    public void setTheaters(Theaters theaters) {
        this.theaters = theaters;
    }

    public Movieposters getMoviePosters() {
        return moviePosters;
    }

    public void setMoviePosters(Movieposters moviePosters) {
        this.moviePosters = moviePosters;
    }

    public String getMoviePosterName() {
        return moviePosterName;
    }

    public void setMoviePosterName(String moviePosterName) {
        this.moviePosterName = moviePosterName;
    }
    
    
    
    //------------ END OF GETTERS & SETTERS ------------//
    
    // Creates a new instance of MainPageManager
    public MainPageManager() {
    }
    
    /**
     * This will return all the movies found in our database using our EJB.
     * @return 
     */
    public List<Movies> getMoviesList()
    {
        return cinemaEJB.findAllMovies();
    }
    
    /**
     * This will return all the movies posters found in our database using our EJB.
     * @return 
     */
    public List<Movieposters> getMoviePostersList()
    {
        return cinemaEJB.findAllMoviePosters();
    }
    
    public String showMoviePosterDetails(Movieposters movieposters)
    {
        // This pulls the parameter value from the front end. This will pull the theater name on whatever row was selected.
        FacesContext fc = FacesContext.getCurrentInstance();
        Map<String,String> params = fc.getExternalContext().getRequestParameterMap();
        moviePosterName = params.get("moviepostername");
        
        Flash flash = FacesContext.getCurrentInstance().getExternalContext().getFlash();
        if (moviePosterName != null) {
            flash.put("moviepostername", moviePosterName);
        } else {
            moviePosterName = (String) flash.get("moviepostername");
        }
        System.out.println(moviePosterName);
        this.moviePosters = movieposters;
        return "MoviePosterDetails.xhtml";
    }
    
    public String goHome()
    {
        return "Home.xhtml";
    }
    

    
}
