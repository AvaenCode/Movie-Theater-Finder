/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author avaen
 */
@Entity
@Table(name = "THEATERS")
@NamedQueries({
    @NamedQuery(name = "Theaters.findAll", query = "SELECT t FROM Theaters t"),
    @NamedQuery(name = "Theaters.findByTheaterid", query = "SELECT t FROM Theaters t WHERE t.theaterid = :theaterid"),
    @NamedQuery(name = "Theaters.findByTheatername", query = "SELECT t FROM Theaters t WHERE t.theatername = :theatername"),
    @NamedQuery(name = "Theaters.findByStreet", query = "SELECT t FROM Theaters t WHERE t.street = :street"),
    @NamedQuery(name = "Theaters.findByCity", query = "SELECT t FROM Theaters t WHERE t.city = :city"),
    @NamedQuery(name = "Theaters.findByLocationstate", query = "SELECT t FROM Theaters t WHERE t.locationstate = :locationstate"),
    @NamedQuery(name = "Theaters.findByZipcode", query = "SELECT t FROM Theaters t WHERE t.zipcode = :zipcode")})
public class Theaters implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "THEATERID")
    private String theaterid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 256)
    @Column(name = "THEATERNAME")
    private String theatername;
    @Size(max = 256)
    @Column(name = "STREET")
    private String street;
    @Size(max = 128)
    @Column(name = "CITY")
    private String city;
    @Size(max = 128)
    @Column(name = "LOCATIONSTATE")
    private String locationstate;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 5)
    @Column(name = "ZIPCODE")
    private String zipcode;
    @ManyToMany(mappedBy = "theatersCollection")
    private Collection<Movies> moviesCollection;

    public Theaters() {
    }

    public Theaters(String theaterid) {
        this.theaterid = theaterid;
    }

    public Theaters(String theaterid, String theatername, String zipcode) {
        this.theaterid = theaterid;
        this.theatername = theatername;
        this.zipcode = zipcode;
    }

    public String getTheaterid() {
        return theaterid;
    }

    public void setTheaterid(String theaterid) {
        this.theaterid = theaterid;
    }

    public String getTheatername() {
        return theatername;
    }

    public void setTheatername(String theatername) {
        this.theatername = theatername;
    }

    public String getStreet() {
        return street;
    }

    public void setStreet(String street) {
        this.street = street;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getLocationstate() {
        return locationstate;
    }

    public void setLocationstate(String locationstate) {
        this.locationstate = locationstate;
    }

    public String getZipcode() {
        return zipcode;
    }

    public void setZipcode(String zipcode) {
        this.zipcode = zipcode;
    }

    public Collection<Movies> getMoviesCollection() {
        return moviesCollection;
    }

    public void setMoviesCollection(Collection<Movies> moviesCollection) {
        this.moviesCollection = moviesCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (theaterid != null ? theaterid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Theaters)) {
            return false;
        }
        Theaters other = (Theaters) object;
        if ((this.theaterid == null && other.theaterid != null) || (this.theaterid != null && !this.theaterid.equals(other.theaterid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entities.Theaters[ theaterid=" + theaterid + " ]";
    }
    
}
