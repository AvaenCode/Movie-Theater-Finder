/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author avaen
 */
@Entity
@Table(name = "MOVIES")
@NamedQueries({
    @NamedQuery(name = "Movies.findAll", query = "SELECT m FROM Movies m"),
    @NamedQuery(name = "Movies.findAllDistinct", query = "SELECT DISTINCT m FROM Movies m"),
    @NamedQuery(name = "Movies.findByMovieid", query = "SELECT m FROM Movies m WHERE m.movieid = :movieid"),
    @NamedQuery(name = "Movies.findByMoviename", query = "SELECT m FROM Movies m WHERE m.moviename = :moviename"),
    @NamedQuery(name = "Movies.findByRuntime", query = "SELECT m FROM Movies m WHERE m.runtime = :runtime"),
    @NamedQuery(name = "Movies.findByDescription", query = "SELECT m FROM Movies m WHERE m.description = :description"),
    @NamedQuery(name = "Movies.findByTheatername", query = "SELECT m FROM Movies m WHERE m.theatername = :theatername"),
    @NamedQuery(name = "Movies.findByShowtime1", query = "SELECT m FROM Movies m WHERE m.showtime1 = :showtime1"),
    @NamedQuery(name = "Movies.findByShowtime2", query = "SELECT m FROM Movies m WHERE m.showtime2 = :showtime2"),
    @NamedQuery(name = "Movies.findByShowtime3", query = "SELECT m FROM Movies m WHERE m.showtime3 = :showtime3"),
    @NamedQuery(name = "Movies.findByShowtime4", query = "SELECT m FROM Movies m WHERE m.showtime4 = :showtime4"),
    @NamedQuery(name = "Movies.findByShowtime5", query = "SELECT m FROM Movies m WHERE m.showtime5 = :showtime5")})
public class Movies implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "MOVIEID")
    private String movieid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 128)
    @Column(name = "MOVIENAME")
    private String moviename;
    @Size(max = 64)
    @Column(name = "RUNTIME")
    private String runtime;
    @Size(max = 1028)
    @Column(name = "DESCRIPTION")
    private String description;
    @Size(max = 256)
    @Column(name = "THEATERNAME")
    private String theatername;
    @Size(max = 16)
    @Column(name = "SHOWTIME1")
    private String showtime1;
    @Size(max = 16)
    @Column(name = "SHOWTIME2")
    private String showtime2;
    @Size(max = 16)
    @Column(name = "SHOWTIME3")
    private String showtime3;
    @Size(max = 16)
    @Column(name = "SHOWTIME4")
    private String showtime4;
    @Size(max = 16)
    @Column(name = "SHOWTIME5")
    private String showtime5;
    @JoinTable(name = "PLAYLOCATION", joinColumns = {
        @JoinColumn(name = "MOVIEID", referencedColumnName = "MOVIEID")}, inverseJoinColumns = {
        @JoinColumn(name = "THEATERID", referencedColumnName = "THEATERID")})
    @ManyToMany
    private Collection<Theaters> theatersCollection;

    public Movies() {
    }

    public Movies(String movieid) {
        this.movieid = movieid;
    }

    public Movies(String movieid, String moviename) {
        this.movieid = movieid;
        this.moviename = moviename;
    }

    public String getMovieid() {
        return movieid;
    }

    public void setMovieid(String movieid) {
        this.movieid = movieid;
    }

    public String getMoviename() {
        return moviename;
    }

    public void setMoviename(String moviename) {
        this.moviename = moviename;
    }

    public String getRuntime() {
        return runtime;
    }

    public void setRuntime(String runtime) {
        this.runtime = runtime;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getTheatername() {
        return theatername;
    }

    public void setTheatername(String theatername) {
        this.theatername = theatername;
    }

    public String getShowtime1() {
        return showtime1;
    }

    public void setShowtime1(String showtime1) {
        this.showtime1 = showtime1;
    }

    public String getShowtime2() {
        return showtime2;
    }

    public void setShowtime2(String showtime2) {
        this.showtime2 = showtime2;
    }

    public String getShowtime3() {
        return showtime3;
    }

    public void setShowtime3(String showtime3) {
        this.showtime3 = showtime3;
    }

    public String getShowtime4() {
        return showtime4;
    }

    public void setShowtime4(String showtime4) {
        this.showtime4 = showtime4;
    }

    public String getShowtime5() {
        return showtime5;
    }

    public void setShowtime5(String showtime5) {
        this.showtime5 = showtime5;
    }

    public Collection<Theaters> getTheatersCollection() {
        return theatersCollection;
    }

    public void setTheatersCollection(Collection<Theaters> theatersCollection) {
        this.theatersCollection = theatersCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (movieid != null ? movieid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Movies)) {
            return false;
        }
        Movies other = (Movies) object;
        if ((this.movieid == null && other.movieid != null) || (this.movieid != null && !this.movieid.equals(other.movieid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entities.Movies[ movieid=" + movieid + " ]";
    }
    
}
