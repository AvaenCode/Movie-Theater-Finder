/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

/**
 *
 * @author avaen
 */
@Entity
@Table(name = "MOVIEPOSTERS")
@NamedQueries({
    @NamedQuery(name = "Movieposters.findAll", query = "SELECT m FROM Movieposters m"),
    @NamedQuery(name = "Movieposters.findByMovieposterid", query = "SELECT m FROM Movieposters m WHERE m.movieposterid = :movieposterid"),
    @NamedQuery(name = "Movieposters.findByMoviename", query = "SELECT m FROM Movieposters m WHERE m.moviename = :moviename"),
    @NamedQuery(name = "Movieposters.findByRuntime", query = "SELECT m FROM Movieposters m WHERE m.runtime = :runtime"),
    @NamedQuery(name = "Movieposters.findByDescription", query = "SELECT m FROM Movieposters m WHERE m.description = :description"),
    @NamedQuery(name = "Movieposters.findByPoster", query = "SELECT m FROM Movieposters m WHERE m.poster = :poster")})
public class Movieposters implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 6)
    @Column(name = "MOVIEPOSTERID")
    private String movieposterid;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 128)
    @Column(name = "MOVIENAME")
    private String moviename;
    @Size(max = 64)
    @Column(name = "RUNTIME")
    private String runtime;
    @Size(max = 1028)
    @Column(name = "DESCRIPTION")
    private String description;
    @Size(max = 256)
    @Column(name = "POSTER")
    private String poster;

    public Movieposters() {
    }

    public Movieposters(String movieposterid) {
        this.movieposterid = movieposterid;
    }

    public Movieposters(String movieposterid, String moviename) {
        this.movieposterid = movieposterid;
        this.moviename = moviename;
    }

    public String getMovieposterid() {
        return movieposterid;
    }

    public void setMovieposterid(String movieposterid) {
        this.movieposterid = movieposterid;
    }

    public String getMoviename() {
        return moviename;
    }

    public void setMoviename(String moviename) {
        this.moviename = moviename;
    }

    public String getRuntime() {
        return runtime;
    }

    public void setRuntime(String runtime) {
        this.runtime = runtime;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPoster() {
        return poster;
    }

    public void setPoster(String poster) {
        this.poster = poster;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (movieposterid != null ? movieposterid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Movieposters)) {
            return false;
        }
        Movieposters other = (Movieposters) object;
        if ((this.movieposterid == null && other.movieposterid != null) || (this.movieposterid != null && !this.movieposterid.equals(other.movieposterid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Entities.Movieposters[ movieposterid=" + movieposterid + " ]";
    }
    
}
