/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EJBs;

import Entities.Movieposters;
import Entities.Movies;
import Entities.Theaters;
import java.util.List;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author avaen
 */
@Stateless
public class CinemaEJB {

    @PersistenceContext(unitName = "CinemaFinderPU")
    private EntityManager em;

    public void persist(Object object) {
        em.persist(object);
    }

    /**
     * This will return all the movies found in our database using the Named Queries from our Entities files.
     *  Format: createNamedQuery("The Query Method found in Movie.java", The class to pull from) 
     *  where getResultList returns the results in a type List.
     * @return 
     */
    public List<Movies> findAllMovies()
    {
        return em.createNamedQuery("Movies.findAll", Movies.class).getResultList();
    }
    
    /**
     * This will return all the movies posters found in our database using the Named Queries from our Entities files.
     *  Format: createNamedQuery("The Query Method found in Movieposters.java", The class to pull from) 
     *  where getResultList returns the results in a type List.
     * @return 
     */
    public List<Movieposters> findAllMoviePosters()
    {
        return em.createNamedQuery("Movieposters.findAll", Movieposters.class).getResultList();
    }
    
    /**
     * This will return all the movies found by theater name using the Named Queries from our Entities files.
     *  Format: createNamedQuery("The Query Method found in movies.java", The class to pull from)
     *  setParameter("The target column name", the value to be used)
     *  where setMaxResults(1) is used to bypass the NonUniqueResultException,
     *  where getSingleResult returns the one single query result.
     * This method is mainly used to populate the actual query. 
     * @param theaterName
     * @return 
     */
    public Movies findMoviesByTheater(String theaterName){
        return em.createNamedQuery("Movies.findByTheatername", Movies.class).setParameter("theatername", theaterName).setMaxResults(1).getSingleResult();
    }
    
    /**
     * This will return all the theaters found in our database using the Named Queries from our Entities files.
     *  Format: createNamedQuery("The Query Method found in theater.java", The class to pull from) 
     *  where getResultList returns the results in a type List.
     * @return 
     */
    public List<Theaters> findAllTheaters()
    {
        return em.createNamedQuery("Theaters.findAll", Theaters.class).getResultList();
    }
    
    
    /**
     * This will return all the theaters found by a specific theater name using the Named Queries from our Entities files.
     *  Format: createNamedQuery("The Query Method found in theater.java", The class to pull from)
     *  setParameter("The target column name", the value to be used)
     *  where getSingleResult returns the one single query result.
     * @param theaterName
     * @return 
     */
    public Theaters findTheatersByName(String theaterName)
    {
        return em.createNamedQuery("Theaters.findByTheatername", Theaters.class).setParameter("theatername", theaterName).getSingleResult();
    }
    
    /**
     * This will return all the theaters found by a specific zipcode using the Named Queries from our Entities files.
     *  Format: createNamedQuery("The Query Method found in theater.java", The class to pull from)
     *  setParameter("The target column name", the value to be used)
     *  where setMaxResults(1) is used to bypass the NonUniqueResultException,
     *  where getSingleResult returns the one single query result.
     * This method is mainly used to populate the actual query. 
     * @param theaterName
     * @return 
     */
    public Theaters findTheatersByZipcode(String zipcode)
    {
        return em.createNamedQuery("Theaters.findByZipcode", Theaters.class).setParameter("zipcode", zipcode).setMaxResults(1).getSingleResult();
    }
    
    /**
     * This will return all the theaters in a list found by a specific zipcode using the Named Queries from our Entities files.
     *  Format: createNamedQuery("The Query Method found in Theaters.java", The class to pull from)
     *  setParameter("The target column name", the value to be used)
     *  where getResultList returns all query results in a list.
     * This method is mainly used to actually display the query results on the front end.
     * @param zipcode
     * @return 
     */
    public List<Theaters> getTheatersByZipcodeList(String zipcode)
    {
        return em.createNamedQuery("Theaters.findByZipcode", Theaters.class).setParameter("zipcode", zipcode).getResultList();
    }
    
    /**
     * This will return all the movies in a list found by a specific zipcode using the Named Queries from our Entities files.
     *  Format: createNamedQuery("The Query Method found in Movies.java", The class to pull from)
     *  setParameter("The target column name", the value to be used)
     *  where getResultList returns all query results in a list.
     * This method is mainly used to actually display the query results on the front end.
     * @param theaterName
     * @return 
     */
    public List<Movies> findMoviesByTheatersList(String theaterName)
    {
        return em.createNamedQuery("Movies.findByTheatername", Movies.class).setParameter("theatername", theaterName).getResultList();
    }

}
